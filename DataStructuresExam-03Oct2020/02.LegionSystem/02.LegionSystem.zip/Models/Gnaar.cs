﻿namespace _02.LegionSystem.Models
{
    public class Gnaar : Enemy
    {
        public Gnaar(int attackSpeed, int health) 
            : base(attackSpeed, health)
        {
        }
    }
}
